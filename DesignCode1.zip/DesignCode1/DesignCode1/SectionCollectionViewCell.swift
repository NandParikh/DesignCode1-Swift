//
//  SectionCollectionViewCell.swift
//  DesignCode1
//
//  Created by Nand Parikh on 08/03/21.
//

import UIKit

class SectionCollectionViewCell: UICollectionViewCell {
    @IBOutlet weak var coverImageView : UIImageView!
    @IBOutlet weak var titleLabel : UILabel!
    @IBOutlet weak var captionLabel: UILabel!
}
