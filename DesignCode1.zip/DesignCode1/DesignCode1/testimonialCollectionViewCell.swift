//
//  testimonialCollectionViewCell.swift
//  DesignCode1
//
//  Created by Nand Parikh on 08/03/21.
//

import UIKit

class testimonialCollectionViewCell: UICollectionViewCell {
    @IBOutlet weak var testLabel : UILabel!
    @IBOutlet weak var nameLabel : UILabel!
    @IBOutlet weak var jobLabel : UILabel!
    @IBOutlet weak var avatarImageView : UIImageView!
}
