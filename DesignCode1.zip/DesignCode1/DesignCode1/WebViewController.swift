//
//  WebViewController.swift
//  DesignCode1
//
//  Created by Nand Parikh on 15/03/21.
//

import UIKit
import WebKit

class WebViewController: UIViewController {

    @IBOutlet weak var webView: WKWebView!
    var urlString : String!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        let url = URL(string: urlString)
        let request = URLRequest(url: url!)
        webView.load(request)
        
        webView.addObserver(self, forKeyPath: #keyPath(WKWebView.estimatedProgress), options: .new, context: nil)
    }
    
    deinit {
        webView.removeObserver(self, forKeyPath: #keyPath(WKWebView.estimatedProgress))
    }
    
    
    override func observeValue(forKeyPath keyPath: String?, of object: Any?, change: [NSKeyValueChangeKey : Any]?, context: UnsafeMutableRawPointer?) {
        if keyPath == "estimatedProgress" {
            
            let progress : String = "\(webView.estimatedProgress)" + " %"
            print("Progress is : %.2f",progress)
            if webView.estimatedProgress == 1.0 {
                navigationItem.title = webView.title
                
            }else {
                navigationItem.title = "Loading..."
            }
        }
    }
    @IBAction func doneButtonTapped(_ sender: UIBarButtonItem) {
        dismiss(animated: true) {
            
        }
    }
    
    @IBAction func actionButtonTapped(_ sender: UIBarButtonItem) {
        let activityController : UIActivityViewController = UIActivityViewController(activityItems: [urlString!], applicationActivities: nil)
        activityController.excludedActivityTypes = [.postToFacebook]
        present(activityController, animated: true, completion: nil)
    }
    
    @IBAction func safariButtonTapped(_ sender: UIBarButtonItem) {
        
        let url : URL = URL(string: urlString)!
        if(UIApplication.shared.canOpenURL(url)){
            UIApplication.shared.open(url, options: [:], completionHandler: nil)
        }
        
    }
    
    @IBAction func goBack(_ sender: UIBarButtonItem) {
        webView.goBack()
    }
    
    @IBAction func goForward(_ sender: UIBarButtonItem) {
        webView.goForward()
    }
    
    @IBAction func reload(_ sender: UIBarButtonItem) {
        webView.reload()
    }
    

}
