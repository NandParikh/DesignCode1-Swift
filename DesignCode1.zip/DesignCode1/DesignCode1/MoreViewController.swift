//
//  MoreViewController.swift
//  DesignCode1
//
//  Created by Nand Parikh on 15/03/21.
//

import UIKit

class MoreViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    @IBAction func safariButtonTapped(_ sender: UIButton) {
        
        performSegue(withIdentifier: "Move to Web", sender: "https://www.google.com")
    }
    @IBAction func communityButtonTapped(_ sender: UIButton) {
        performSegue(withIdentifier: "Move to Web", sender: "https://www.apple.com")

    }
    
    @IBAction func twitterButtonTapped(_ sender: UIButton) {
        performSegue(withIdentifier: "Move to Web", sender: "https://www.twitter.com")

    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        if let identifier = segue.identifier, identifier == "Move to Web"{
            
            let toNav = segue.destination as! UINavigationController
            let toVC = toNav.viewControllers.first as! WebViewController
            
            toVC.urlString = sender as? String
        }
    }
}
